/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package quizapp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import quizapp.ui.Login;
import repositories.JsonFileRepository;

/**
 *
 * @author x
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        new Login().setVisible(true);
        // TODO code application logic here
//        HashMap<String, String> map = new HashMap<>();
//        map.put("1", "Mango");  //Put elements in Map  
//        map.put("2", "Apple");
//        map.put("3", "Banana");
//        map.put("4", "Grapes");
//        JsonFileRepository j = new JsonFileRepository("resources/databases/questions.json");
////        j.createItemsInJsonFile(map);
//
//        List<String> a = new ArrayList<>();
////        a.add("question");
////        a.add("optionA");
////        a.add("optionB");
////        a.add("optionC");
////        a.add("optionD");
////        a.add("answer");
//
//        a.add("1");
//        a.add("2");
//        a.add("3");
//        a.add("4");
        
//        j.getRandomRows(0, a);

    }

}
